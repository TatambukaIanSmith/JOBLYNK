<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Worker Dashboard - JOB-lyNK</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'blue-primary': '#1e40af',
                        'blue-secondary': '#3b82f6',
                        'blue-light': '#dbeafe',
                        'blue-dark': '#1e3a8a'
                    }
                }
            }
        }
    </script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="bg-blue-primary shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <a href="index.html" id="job-click" class="text-white text-2xl font-bold">JOB-lyNK</a>
                    </div>
                    <div class="hidden md:block ml-10">
                        <div class="flex items-baseline space-x-4">
                            <a href="/worker" class="text-white px-3 py-2 rounded-md text-sm font-medium">Dashboard</a>
                            <a href="/jobs" class="text-blue-light hover:text-white px-3 py-2 rounded-md text-sm font-medium">Find Jobs</a>
                            <a href="#" class="text-blue-light hover:text-white px-3 py-2 rounded-md text-sm font-medium">My Applications</a>
                            <a href="/messages" class="text-blue-light hover:text-white px-3 py-2 rounded-md text-sm font-medium">Messages</a>
                        </div>
                    </div>
                </div>
                <div class="flex items-center space-x-4">
                    <button class="text-white hover:text-blue-light">
                        <i class="fas fa-bell text-xl"></i>
                        <span class="absolute -mt-2 -mr-1 px-1.5 py-0.5 bg-red-500 text-xs text-white rounded-full">3</span>
                    </button>
                    <div class="relative group">
                        <button class="flex items-center text-white hover:text-blue-light">
                            <img class="h-8 w-8 rounded-full" src="https://via.placeholder.com/40" alt="Profile">
                            <span class="ml-2">Smith</span>
                            <i class="fas fa-chevron-down ml-1"></i>
                        </button>
                        <div class="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-lg hidden group-hover:block">
                            <a href="#" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Profile</a>
                            <a href="/settings" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Settings</a>
                            <a href="/home" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">Logout</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </nav>

    <div class="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <!-- Welcome Section -->
        <div class="bg-gradient-to-r from-blue-primary to-blue-secondary rounded-lg p-6 mb-6">
            <div class="flex items-center justify-between">
                <div class="text-white">
                    <h1 class="text-3xl font-bold">Welcome back, John!</h1>
                    <p class="text-blue-light mt-1">Ready to find your next opportunity?</p>
                </div>
                <div class="text-white text-right">
                    <div class="text-2xl font-bold">4.8 ⭐</div>
                    <div class="text-blue-light">Your Rating</div>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-briefcase text-2xl text-blue-primary"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Active Jobs</p>
                        <p class="text-2xl font-semibold text-gray-900">3</p>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-check-circle text-2xl text-green-500"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Completed Jobs</p>
                        <p class="text-2xl font-semibold text-gray-900">27</p>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-dollar-sign text-2xl text-green-500"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">This Month</p>
                        <p class="text-2xl font-semibold text-gray-900">$2,450</p>
                    </div>
                </div>
            </div>
            <div class="bg-white rounded-lg shadow p-6">
                <div class="flex items-center">
                    <div class="flex-shrink-0">
                        <i class="fas fa-clock text-2xl text-blue-secondary"></i>
                    </div>
                    <div class="ml-4">
                        <p class="text-sm font-medium text-gray-500">Hours Worked</p>
                        <p class="text-2xl font-semibold text-gray-900">156</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <!-- Earnings Chart -->
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Earnings Overview</h3>
                <canvas id="earningsChart" height="200"></canvas>
            </div>

            <!-- Recent Activities -->
            <div class="bg-white rounded-lg shadow p-6">
                <h3 class="text-lg font-semibold text-gray-900 mb-4">Recent Activities</h3>
                <div class="space-y-4">
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-check-circle text-green-500"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900">Completed: House Cleaning</p>
                            <p class="text-sm text-gray-500">2 hours ago • $85</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-clock text-blue-primary"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900">Started: Garden Maintenance</p>
                            <p class="text-sm text-gray-500">1 day ago • In Progress</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-plus-circle text-blue-secondary"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900">Applied: Event Setup</p>
                            <p class="text-sm text-gray-500">3 days ago • Pending</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <div class="flex-shrink-0">
                            <i class="fas fa-star text-yellow-500"></i>
                        </div>
                        <div class="ml-3">
                            <p class="text-sm font-medium text-gray-900">Received 5-star review</p>
                            <p class="text-sm text-gray-500">5 days ago • Delivery Service</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Active Jobs -->
            <div class="lg:col-span-2 bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900">Active Jobs</h3>
                </div>
                <div class="p-6">
                    <div class="space-y-4">
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h4 class="font-semibold text-gray-900">Office Cleaning</h4>
                                    <p class="text-sm text-gray-600">Downtown Business Center</p>
                                    <div class="flex items-center mt-2">
                                        <i class="fas fa-clock text-blue-primary mr-1"></i>
                                        <span class="text-sm text-gray-500">Due: Today 5:00 PM</span>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <div class="text-lg font-semibold text-green-600">$120</div>
                                    <span class="bg-yellow-100 text-yellow-800 text-xs px-2 py-1 rounded-full">In Progress</span>
                                </div>
                            </div>
                            <div class="mt-3 flex space-x-2">
                                <button class="bg-blue-primary text-white px-3 py-1 rounded text-sm hover:bg-blue-dark">
                                    Mark Complete
                                </button>
                                <button class="border border-gray-300 text-gray-700 px-3 py-1 rounded text-sm hover:bg-gray-50">
                                    Message Client
                                </button>
                            </div>
                        </div>
                        
                        <div class="border border-gray-200 rounded-lg p-4">
                            <div class="flex items-center justify-between">
                                <div>
                                    <h4 class="font-semibold text-gray-900">Delivery Service</h4>
                                    <p class="text-sm text-gray-600">Restaurant to Customer</p>
                                    <div class="flex items-center mt-2">
                                        <i class="fas fa-clock text-blue-primary mr-1"></i>
                                        <span class="text-sm text-gray-500">Due: Tomorrow 12:00 PM</span>
                                    </div>
                                </div>
                                <div class="text-right">
                                    <div class="text-lg font-semibold text-green-600">$25</div>
                                    <span class="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full">Scheduled</span>
                                </div>
                            </div>
                            <div class="mt-3 flex space-x-2">
                                <button class="bg-blue-primary text-white px-3 py-1 rounded text-sm hover:bg-blue-dark">
                                    Start Job
                                </button>
                                <button class="border border-gray-300 text-gray-700 px-3 py-1 rounded text-sm hover:bg-gray-50">
                                    View Details
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white rounded-lg shadow">
                <div class="px-6 py-4 border-b border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-900">Quick Actions</h3>
                </div>
                <div class="p-6">
                    <div class="space-y-3">
                        <a href="jobs.html" class="block w-full bg-blue-primary text-white text-center py-2 px-4 rounded-lg hover:bg-blue-dark transition duration-300">
                            <i class="fas fa-search mr-2"></i>
                            Find New Jobs
                        </a>
                        <button class="block w-full bg-gray-100 text-gray-700 text-center py-2 px-4 rounded-lg hover:bg-gray-200 transition duration-300">
                            <i class="fas fa-user-edit mr-2"></i>
                            Update Profile
                        </button>
                        <button class="block w-full bg-gray-100 text-gray-700 text-center py-2 px-4 rounded-lg hover:bg-gray-200 transition duration-300">
                            <i class="fas fa-file-invoice-dollar mr-2"></i>
                            View Earnings
                        </button>
                        <button class="block w-full bg-gray-100 text-gray-700 text-center py-2 px-4 rounded-lg hover:bg-gray-200 transition duration-300">
                            <i class="fas fa-star mr-2"></i>
                            My Reviews
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recommended Jobs -->
        <div class="mt-6 bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-900">Recommended Jobs for You</h3>
            </div>
            <div class="p-6">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition duration-300">
                        <h4 class="font-semibold text-gray-900">Apartment Cleaning</h4>
                        <p class="text-sm text-gray-600 mt-1">2-bedroom apartment, deep clean needed</p>
                        <div class="flex items-center justify-between mt-3">
                            <span class="text-lg font-semibold text-green-600">$95</span>
                            <span class="text-sm text-gray-500">3 hours</span>
                        </div>
                        <button class="mt-3 w-full bg-blue-primary text-white py-2 rounded hover:bg-blue-dark transition duration-300">
                            Apply Now
                        </button>
                    </div>
                    
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition duration-300">
                        <h4 class="font-semibold text-gray-900">Event Photography</h4>
                        <p class="text-sm text-gray-600 mt-1">Birthday party, 4-hour coverage</p>
                        <div class="flex items-center justify-between mt-3">
                            <span class="text-lg font-semibold text-green-600">$200</span>
                            <span class="text-sm text-gray-500">4 hours</span>
                        </div>
                        <button class="mt-3 w-full bg-blue-primary text-white py-2 rounded hover:bg-blue-dark transition duration-300">
                            Apply Now
                        </button>
                    </div>
                    
                    <div class="border border-gray-200 rounded-lg p-4 hover:shadow-md transition duration-300">
                        <h4 class="font-semibold text-gray-900">Garden Setup</h4>
                        <p class="text-sm text-gray-600 mt-1">Small backyard landscaping project</p>
                        <div class="flex items-center justify-between mt-3">
                            <span class="text-lg font-semibold text-green-600">$150</span>
                            <span class="text-sm text-gray-500">5 hours</span>
                        </div>
                        <button class="mt-3 w-full bg-blue-primary text-white py-2 rounded hover:bg-blue-dark transition duration-300">
                            Apply Now
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Earnings Chart
        const ctx = document.getElementById('earningsChart').getContext('2d');
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'Monthly Earnings',
                    data: [1200, 1800, 1600, 2100, 2300, 2450],
                    borderColor: '#1e40af',
                    backgroundColor: 'rgba(30, 64, 175, 0.1)',
                    borderWidth: 3,
                    fill: true,
                    tension: 0.4
                }]
            },

            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return '$' + value;
                            }
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
        //here tulabe
        document.getElementById('job-click').addEventListener('click', function() {
            window.location.href = 'index.html';
        });
    </script>
</body>
</html>

