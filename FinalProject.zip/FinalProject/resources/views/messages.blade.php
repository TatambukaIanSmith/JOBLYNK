<?php
require_once 'config.php'; 

// Check for logged-in worker
if (!isset($_SESSION['loggedin']) || $_SESSION['user_type'] !== 'worker') {
    header("Location: login.html");
    exit();
}

$employer_id = $_GET['employer_id'] ?? null;
$job_id = $_GET['job_id'] ?? null;
$worker_id = $_SESSION['user_id'];

// --- Backend Logic Placeholder: Fetch messages and employer/job details ---
// In a real application, you'd fetch:
// 1. Employer details (name, company) using $employer_id.
// 2. Job title using $job_id.
// 3. Conversation history between $worker_id and $employer_id for this $job_id.

$employer_name = "TechCorp Inc."; // Placeholder
$job_title = "Senior PHP Developer"; // Placeholder
$messages = [
    ['sender' => 'employer', 'text' => 'Hello! We saw your application/interest in our PHP role. How can we help?', 'time' => '10:00 AM'],
    ['sender' => 'worker', 'text' => 'Hi, I had a quick question about the remote work policy.', 'time' => '10:05 AM']
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages - <?php echo htmlspecialchars($employer_name); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        'blue-primary': '#1e40af', 'blue-secondary': '#3b82f6', 
                        'blue-light': '#dbeafe', 'blue-dark': '#1e3a8a' 
                    }
                }
            }
        }
    </script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen">
    
    <nav class="bg-blue-primary shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
                <div class="flex items-center">
                    <a href="dashboard.php" class="text-white text-2xl font-bold">JOB-lyNK</a>
                </div>
                <div class="flex items-center space-x-4">
                    <a href="dashboard.php" class="text-blue-light hover:text-white px-3 py-2 rounded-md text-sm font-medium">Dashboard</a>
                    <a href="logout.php" class="bg-blue-secondary text-white hover:bg-blue-dark px-3 py-2 rounded-md text-sm font-medium transition duration-300">Logout</a>
                </div>
            </div>
        </div>
    </nav>

    <main class="max-w-3xl mx-auto py-10 px-4 sm:px-6 lg:px-8">
        <div class="bg-white shadow overflow-hidden rounded-lg">
            
            <div class="bg-blue-primary text-white p-4 flex justify-between items-center">
                <div>
                    <h1 class="text-lg font-semibold">Chat with <?php echo htmlspecialchars($employer_name); ?></h1>
                    <p class="text-sm opacity-75">Regarding: <?php echo htmlspecialchars($job_title); ?></p>
                </div>
                <a href="jobs.php" class="text-blue-light hover:text-white">
                    <i class="fas fa-times"></i> Close
                </a>
            </div>

            <div class="p-4 h-96 overflow-y-auto space-y-4 bg-gray-50">
                <?php foreach ($messages as $msg): ?>
                    <?php if ($msg['sender'] === 'employer'): ?>
                        <div class="flex justify-start">
                            <div class="bg-gray-200 text-gray-800 rounded-lg p-3 max-w-xs md:max-w-md">
                                <p class="text-sm"><?php echo htmlspecialchars($msg['text']); ?></p>
                                <span class="text-xs text-gray-500 block text-right mt-1"><?php echo htmlspecialchars($msg['time']); ?></span>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="flex justify-end">
                            <div class="bg-blue-light text-blue-dark rounded-lg p-3 max-w-xs md:max-w-md">
                                <p class="text-sm"><?php echo htmlspecialchars($msg['text']); ?></p>
                                <span class="text-xs text-gray-600 block text-right mt-1"><?php echo htmlspecialchars($msg['time']); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>

            <form action="send_message.php" method="POST" class="p-4 border-t flex space-x-3">
                <input type="hidden" name="receiver_id" value="<?php echo htmlspecialchars($employer_id); ?>">
                <input type="hidden" name="job_id" value="<?php echo htmlspecialchars($job_id); ?>">
                
                <textarea name="message" rows="1" required placeholder="Type your message or initial query..."
                    class="flex-grow px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-primary resize-none"></textarea>
                
                <button type="submit" 
                    class="bg-blue-secondary text-white px-4 rounded-lg font-semibold hover:bg-blue-dark transition duration-300">
                    <i class="fas fa-paper-plane"></i> Send
                </button>
            </form>
        </div>
    </main>

</body>
</html>