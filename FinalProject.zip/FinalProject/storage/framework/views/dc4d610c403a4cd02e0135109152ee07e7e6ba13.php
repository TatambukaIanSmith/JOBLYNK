

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Job Matching Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        body {
            background-color: #f0f8ff;
        }
        .sidebar {
            background-color: #004aad;
        }
    </style>
</head>
<body class="flex h-screen font-sans">

    <!-- Sidebar -->
    <div class="sidebar w-64 flex flex-col text-white">
        <div class="p-6 text-2xl font-semibold border-b border-blue-800">JobMatch Admin</div>
        <nav class="flex flex-col flex-1 p-4 space-y-2">
            <a href="dashboard.html" class="hover:bg-blue-800 p-2 rounded flex items-center">Dashboard Overview</a>
            <a href="jobs.html" class="hover:bg-blue-800 p-2 rounded flex items-center">Manage Jobs</a>
            <a href="employers.html" class="hover:bg-blue-800 p-2 rounded flex items-center">Employers & Employers</a>
            <a href="workers.html" class="hover:bg-blue-800 p-2 rounded flex items-center">Worker Profiles</a>
            <a href="analytics.html" class="hover:bg-blue-800 p-2 rounded flex items-center">Analytics</a>
            <a href="settings.html" class="hover:bg-blue-800 p-2 rounded flex items-center">Settings</a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="flex-1 flex flex-col">
        <header class="bg-white shadow p-4 flex justify-between items-center border-b">
            <h1 class="text-xl font-bold">Dashboard</h1>
            <div class="flex items-center space-x-4">
                <form method="GET" action="dashboard.html">
                    <input type="text" name="search" placeholder="Search..." class="border rounded p-2" />
                </form>
                <form method="POST" action="logout.html">
                    <button type="submit" class="bg-blue-600 text-white p-2 rounded">Logout</button>
                </form>
            </div>
        </header>

        <main class="p-6 space-y-6 overflow-y-auto">

            <!-- Stats Cards -->
            <div class="grid grid-cols-4 gap-6">
                <div class="bg-white shadow rounded p-4">
                    <h2 class="text-gray-700 font-bold">Total Jobs</h2>
                    <p class="text-2xl font-semibold">0</p>
                </div>
                <div class="bg-white shadow rounded p-4">
                    <h2 class="text-gray-700 font-bold">Employers</h2>
                    <p class="text-2xl font-semibold">0</p>
                </div>
                <div class="bg-white shadow rounded p-4">
                    <h2 class="text-gray-700 font-bold">Workers</h2>
                    <p class="text-2xl font-semibold">0</p>
                </div>
                <div class="bg-white shadow rounded p-4">
                    <h2 class="text-gray-700 font-bold">Matches Today</h2>
                    <p class="text-2xl font-semibold">0</p>
                </div>
            </div>

            <!-- Jobs Management -->
            <div class="bg-white shadow rounded p-6">
                <h2 class="text-lg font-bold mb-4">Jobs Management</h2>
                <table class="min-w-full table-auto" id="jobsTable">
                    <thead>
                        <tr class="bg-blue-100">
                            <th class="px-4 py-2">Job Title</th>
                            <th class="px-4 py-2">Employer</th>
                            <th class="px-4 py-2">Status</th>
                            <th class="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Jobs rows will be dynamically inserted here via JavaScript -->
                    </tbody>
                </table>
            </div>

            <!-- Employers Management -->
            <div class="bg-white shadow rounded p-6">
                <h2 class="text-lg font-bold mb-4">Employers Management</h2>
                <table class="min-w-full table-auto" id="employersTable">
                    <thead>
                        <tr class="bg-blue-100">
                            <th class="px-4 py-2">Employer Name</th>
                            <th class="px-4 py-2">Email</th>
                            <th class="px-4 py-2">Status</th>
                            <th class="px-4 py-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- Employers rows will be dynamically inserted here via JavaScript -->
                    </tbody>
                </table>
            </div>

        </main>
    </div>

    <script>
        const employersData = [
            { id: 1, name: 'Company A', email: 'contact@companya.com', status: 'Active' },
            { id: 2, name: 'Company B', email: 'contact@companyb.com', status: 'Pending' }
        ];

        const jobsData = [
            { id: 1, title: 'Software Engineer', employer: 'Company A', status: 'Open' },
            { id: 2, title: 'Web Designer', employer: 'Company B', status: 'Closed' }
        ];

        function renderTable(tableId, data, type) {
            const tableBody = document.getElementById(tableId).getElementsByTagName('tbody')[0];
            data.forEach(item => {
                let row = tableBody.insertRow();
                Object.keys(item).forEach(key => {
                    let cell = row.insertCell();
                    cell.textContent = item[key];
                });
                let actionCell = row.insertCell();
                actionCell.innerHTML = `<button onclick='manage${type}(${item.id})' class='text-green-600'>Manage</button>`;
            });
        }

        function manageEmployers(id) {
            alert(`Managing Employer ID: ${id}`);
        }

        function manageJobs(id) {
            alert(`Managing Job ID: ${id}`);
        }

        renderTable('employersTable', employersData, 'Employers');
        renderTable('jobsTable', jobsData, 'Jobs');
    </script>

</body>
</html>
<!-- <?php $conn->close(); ?>    
    roleSelect.addEventListener('change', function() {
      if (this.value === 'Other') {
        otherRoleField.style.display = 'block';
      } else {
        otherRoleField.style.display = 'none';
      }
    });

    const form = document.getElementById('casualJobForm');
    const confirmationMessage = document.getElementById('confirmationMessage');
    const errorMessage = document.getElementById('errorMessage');

    form.addEventListener('submit', function(event) {
      event.preventDefault();
      // Simple front-end validation can be added here if needed

      // Simulate successful submission
      confirmationMessage.classList.remove('hidden');
      errorMessage.classList.add('hidden');
      form.reset();
      otherRoleField.style.display = 'none';
    });
  </script> --><?php /**PATH C:\Users\HP 745 G5\OneDrive\Desktop\FinalProject\resources\views/admin.blade.php ENDPATH**/ ?>