-- =============================================
-- CasualWork Job Matching Platform Database Schema
-- Version: 1.0
-- Created: 2024
-- =============================================

-- Create database
CREATE DATABASE IF NOT EXISTS casualwork_db;
USE casualwork_db;

-- =============================================
-- USERS AND AUTHENTICATION
-- =============================================

-- Main users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    user_type ENUM('worker', 'employer', 'admin') NOT NULL,
    status ENUM('active', 'suspended', 'pending_verification', 'inactive') DEFAULT 'pending_verification',
    email_verified BOOLEAN DEFAULT FALSE,
    phone_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    last_login TIMESTAMP NULL,
    profile_completed BOOLEAN DEFAULT FALSE,
    
    INDEX idx_email (email),
    INDEX idx_user_type (user_type),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- User profiles (common fields)
CREATE TABLE user_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20),
    profile_picture VARCHAR(500),
    date_of_birth DATE,
    gender ENUM('male', 'female', 'other', 'prefer_not_to_say'),
    bio TEXT,
    location_address TEXT,
    location_city VARCHAR(100),
    location_state VARCHAR(100),
    location_country VARCHAR(100),
    location_latitude DECIMAL(10, 8),
    location_longitude DECIMAL(11, 8),
    timezone VARCHAR(50),
    language_preference VARCHAR(10) DEFAULT 'en',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_location_city (location_city),
    INDEX idx_full_name (first_name, last_name)
);

-- Worker-specific profiles
CREATE TABLE worker_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    experience_level ENUM('beginner', 'intermediate', 'experienced', 'expert') DEFAULT 'beginner',
    hourly_rate_min DECIMAL(8, 2),
    hourly_rate_max DECIMAL(8, 2),
    availability_status ENUM('available', 'busy', 'unavailable') DEFAULT 'available',
    travel_radius INT DEFAULT 10, -- in kilometers
    background_check_status ENUM('pending', 'approved', 'rejected', 'not_required') DEFAULT 'pending',
    identity_verified BOOLEAN DEFAULT FALSE,
    portfolio_url VARCHAR(500),
    resume_url VARCHAR(500),
    total_jobs_completed INT DEFAULT 0,
    total_earnings DECIMAL(12, 2) DEFAULT 0.00,
    average_rating DECIMAL(3, 2) DEFAULT 0.00,
    rating_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_experience (experience_level),
    INDEX idx_availability (availability_status),
    INDEX idx_rating (average_rating),
    INDEX idx_hourly_rate (hourly_rate_min, hourly_rate_max)
);

-- Employer-specific profiles
CREATE TABLE employer_profiles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    company_name VARCHAR(200),
    company_size ENUM('1-10', '11-50', '51-200', '201-1000', '1000+'),
    industry VARCHAR(100),
    company_website VARCHAR(500),
    company_description TEXT,
    verification_status ENUM('pending', 'verified', 'rejected') DEFAULT 'pending',
    business_license VARCHAR(100),
    tax_id VARCHAR(100),
    total_jobs_posted INT DEFAULT 0,
    total_amount_spent DECIMAL(12, 2) DEFAULT 0.00,
    average_rating DECIMAL(3, 2) DEFAULT 0.00,
    rating_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_company_name (company_name),
    INDEX idx_industry (industry),
    INDEX idx_verification (verification_status)
);

-- =============================================
-- SKILLS AND CATEGORIES
-- =============================================

-- Job categories
CREATE TABLE job_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    description TEXT,
    icon VARCHAR(100),
    parent_id INT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (parent_id) REFERENCES job_categories(id) ON DELETE SET NULL,
    INDEX idx_slug (slug),
    INDEX idx_parent_id (parent_id),
    INDEX idx_active (is_active)
);

-- Skills
CREATE TABLE skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    category_id INT,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (category_id) REFERENCES job_categories(id) ON DELETE SET NULL,
    INDEX idx_slug (slug),
    INDEX idx_category (category_id),
    INDEX idx_active (is_active)
);

-- Worker skills (many-to-many)
CREATE TABLE worker_skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    worker_id INT NOT NULL,
    skill_id INT NOT NULL,
    proficiency_level ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'intermediate',
    years_experience DECIMAL(3, 1) DEFAULT 0,
    verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (worker_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE,
    UNIQUE KEY unique_worker_skill (worker_id, skill_id),
    INDEX idx_worker_id (worker_id),
    INDEX idx_skill_id (skill_id)
);

-- =============================================
-- JOBS AND APPLICATIONS
-- =============================================

-- Jobs
CREATE TABLE jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    employer_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    category_id INT,
    job_type ENUM('one-time', 'recurring', 'project', 'temporary', 'permanent') NOT NULL,
    payment_type ENUM('hourly', 'fixed', 'negotiable') NOT NULL,
    budget_min DECIMAL(8, 2),
    budget_max DECIMAL(8, 2),
    currency VARCHAR(3) DEFAULT 'USD',
    estimated_duration VARCHAR(50),
    urgency ENUM('normal', 'urgent', 'asap') DEFAULT 'normal',
    status ENUM('draft', 'active', 'paused', 'completed', 'cancelled', 'expired') DEFAULT 'draft',
    location_type ENUM('remote', 'on_site', 'hybrid') DEFAULT 'on_site',
    location_address TEXT,
    location_city VARCHAR(100),
    location_state VARCHAR(100),
    location_country VARCHAR(100),
    location_latitude DECIMAL(10, 8),
    location_longitude DECIMAL(11, 8),
    start_date DATE,
    end_date DATE,
    application_deadline TIMESTAMP,
    max_applications INT DEFAULT 50,
    featured BOOLEAN DEFAULT FALSE,
    views_count INT DEFAULT 0,
    applications_count INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    published_at TIMESTAMP NULL,
    
    FOREIGN KEY (employer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES job_categories(id) ON DELETE SET NULL,
    INDEX idx_employer_id (employer_id),
    INDEX idx_category_id (category_id),
    INDEX idx_status (status),
    INDEX idx_job_type (job_type),
    INDEX idx_payment_type (payment_type),
    INDEX idx_location_city (location_city),
    INDEX idx_featured (featured),
    INDEX idx_created_at (created_at),
    INDEX idx_budget (budget_min, budget_max)
);

-- Job required skills
CREATE TABLE job_skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    skill_id INT NOT NULL,
    required_level ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'intermediate',
    is_required BOOLEAN DEFAULT TRUE,
    
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills(id) ON DELETE CASCADE,
    UNIQUE KEY unique_job_skill (job_id, skill_id),
    INDEX idx_job_id (job_id),
    INDEX idx_skill_id (skill_id)
);

-- Job applications
CREATE TABLE job_applications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    worker_id INT NOT NULL,
    status ENUM('pending', 'shortlisted', 'accepted', 'rejected', 'withdrawn') DEFAULT 'pending',
    cover_letter TEXT,
    proposed_rate DECIMAL(8, 2),
    proposed_timeline VARCHAR(200),
    portfolio_items TEXT, -- JSON array of portfolio URLs
    availability_start DATE,
    application_score DECIMAL(3, 2) DEFAULT 0, -- matching algorithm score
    viewed_by_employer BOOLEAN DEFAULT FALSE,
    viewed_at TIMESTAMP NULL,
    response_deadline TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (worker_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_job_application (job_id, worker_id),
    INDEX idx_job_id (job_id),
    INDEX idx_worker_id (worker_id),
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
);

-- =============================================
-- CONTRACTS AND WORK
-- =============================================

-- Work contracts
CREATE TABLE contracts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT NOT NULL,
    employer_id INT NOT NULL,
    worker_id INT NOT NULL,
    application_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    contract_type ENUM('hourly', 'fixed', 'milestone') NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    start_date DATE NOT NULL,
    end_date DATE,
    status ENUM('active', 'paused', 'completed', 'cancelled', 'disputed') DEFAULT 'active',
    terms_and_conditions TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE CASCADE,
    FOREIGN KEY (employer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (worker_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (application_id) REFERENCES job_applications(id) ON DELETE CASCADE,
    INDEX idx_job_id (job_id),
    INDEX idx_employer_id (employer_id),
    INDEX idx_worker_id (worker_id),
    INDEX idx_status (status),
    INDEX idx_dates (start_date, end_date)
);

-- Work milestones (for milestone-based contracts)
CREATE TABLE contract_milestones (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contract_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    amount DECIMAL(8, 2) NOT NULL,
    due_date DATE,
    status ENUM('pending', 'in_progress', 'submitted', 'approved', 'rejected') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    
    FOREIGN KEY (contract_id) REFERENCES contracts(id) ON DELETE CASCADE,
    INDEX idx_contract_id (contract_id),
    INDEX idx_status (status),
    INDEX idx_due_date (due_date)
);

-- Time tracking (for hourly contracts)
CREATE TABLE time_entries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contract_id INT NOT NULL,
    worker_id INT NOT NULL,
    description TEXT,
    start_time TIMESTAMP NOT NULL,
    end_time TIMESTAMP,
    duration_minutes INT, -- calculated field
    hourly_rate DECIMAL(8, 2),
    amount DECIMAL(8, 2), -- calculated: duration * hourly_rate
    status ENUM('draft', 'submitted', 'approved', 'rejected') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (contract_id) REFERENCES contracts(id) ON DELETE CASCADE,
    FOREIGN KEY (worker_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_contract_id (contract_id),
    INDEX idx_worker_id (worker_id),
    INDEX idx_status (status),
    INDEX idx_start_time (start_time)
);

-- =============================================
-- PAYMENTS AND TRANSACTIONS
-- =============================================

-- Payment methods
CREATE TABLE payment_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type ENUM('card', 'bank_account', 'mobile_money', 'paypal', 'crypto') NOT NULL,
    provider VARCHAR(50), -- e.g., 'visa', 'mtn', 'airtel', 'paypal'
    account_identifier VARCHAR(255), -- masked card number, phone number, etc.
    account_name VARCHAR(200),
    is_primary BOOLEAN DEFAULT FALSE,
    is_verified BOOLEAN DEFAULT FALSE,
    metadata JSON, -- store additional provider-specific data
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_type (type),
    INDEX idx_provider (provider)
);

-- Transactions
CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    reference_id VARCHAR(100) UNIQUE NOT NULL,
    contract_id INT,
    payer_id INT NOT NULL,
    payee_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    transaction_type ENUM('payment', 'refund', 'withdrawal', 'deposit', 'fee') NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'failed', 'cancelled', 'disputed') DEFAULT 'pending',
    payment_method_id INT,
    gateway_transaction_id VARCHAR(255),
    gateway_response JSON,
    platform_fee DECIMAL(8, 2) DEFAULT 0,
    processing_fee DECIMAL(8, 2) DEFAULT 0,
    description TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    completed_at TIMESTAMP NULL,
    
    FOREIGN KEY (contract_id) REFERENCES contracts(id) ON DELETE SET NULL,
    FOREIGN KEY (payer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (payee_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (payment_method_id) REFERENCES payment_methods(id) ON DELETE SET NULL,
    INDEX idx_reference_id (reference_id),
    INDEX idx_contract_id (contract_id),
    INDEX idx_payer_id (payer_id),
    INDEX idx_payee_id (payee_id),
    INDEX idx_status (status),
    INDEX idx_transaction_type (transaction_type),
    INDEX idx_created_at (created_at)
);

-- Escrow accounts (for secure payments)
CREATE TABLE escrow_accounts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contract_id INT NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'USD',
    status ENUM('pending', 'funded', 'released', 'refunded', 'disputed') DEFAULT 'pending',
    funded_at TIMESTAMP NULL,
    release_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    FOREIGN KEY (contract_id) REFERENCES contracts(id) ON DELETE CASCADE,
    INDEX idx_contract_id (contract_id),
    INDEX idx_status (status),
    INDEX idx_release_date (release_date)
);

-- =============================================
-- REVIEWS AND RATINGS
-- =============================================

-- Reviews
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contract_id INT NOT NULL,
    reviewer_id INT NOT NULL, -- who is giving the review
    reviewee_id INT NOT NULL, -- who is being reviewed
    reviewer_type ENUM('employer', 'worker') NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    title VARCHAR(200),
    comment TEXT,
    work_quality_rating INT CHECK (work_quality_rating >= 1 AND work_quality_rating <= 5),
    communication_rating INT CHECK (communication_rating >= 1 AND communication_rating <= 5),
    professionalism_rating INT CHECK (professionalism_rating >= 1 AND professionalism_rating <= 5),
    would_recommend BOOLEAN,
    is_public BOOLEAN DEFAULT TRUE,
    response_comment TEXT, -- reviewee can respond
    response_date TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (contract_id) REFERENCES contracts(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewer_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (reviewee_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_contract_reviewer (contract_id, reviewer_id),
    INDEX idx_contract_id (contract_id),
    INDEX idx_reviewer_id (reviewer_id),
    INDEX idx_reviewee_id (reviewee_id),
    INDEX idx_rating (rating),
    INDEX idx_reviewer_type (reviewer_type)
);

-- =============================================
-- MESSAGING AND NOTIFICATIONS
-- =============================================

-- Conversations
CREATE TABLE conversations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    job_id INT,
    contract_id INT,
    participant_1_id INT NOT NULL,
    participant_2_id INT NOT NULL,
    title VARCHAR(200),
    status ENUM('active', 'archived', 'blocked') DEFAULT 'active',
    last_message_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (job_id) REFERENCES jobs(id) ON DELETE SET NULL,
    FOREIGN KEY (contract_id) REFERENCES contracts(id) ON DELETE SET NULL,
    FOREIGN KEY (participant_1_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (participant_2_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_job_id (job_id),
    INDEX idx_contract_id (contract_id),
    INDEX idx_participants (participant_1_id, participant_2_id),
    INDEX idx_last_message (last_message_at)
);

-- Messages
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    conversation_id INT NOT NULL,
    sender_id INT NOT NULL,
    message_type ENUM('text', 'file', 'image', 'system') DEFAULT 'text',
    content TEXT,
    file_url VARCHAR(500),
    file_name VARCHAR(255),
    file_size INT,
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (conversation_id) REFERENCES conversations(id) ON DELETE CASCADE,
    FOREIGN KEY (sender_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_conversation_id (conversation_id),
    INDEX idx_sender_id (sender_id),
    INDEX idx_created_at (created_at),
    INDEX idx_is_read (is_read)
);

-- Notifications
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    type VARCHAR(50) NOT NULL, -- e.g., 'job_application', 'payment_received', 'message'
    title VARCHAR(200) NOT NULL,
    content TEXT,
    related_id INT, -- ID of related entity (job, contract, etc.)
    related_type VARCHAR(50), -- type of related entity
    action_url VARCHAR(500),
    is_read BOOLEAN DEFAULT FALSE,
    read_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NULL,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_type (type),
    INDEX idx_is_read (is_read),
    INDEX idx_created_at (created_at)
);

-- =============================================
-- SUPPORT AND DISPUTES
-- =============================================

-- Support tickets
CREATE TABLE support_tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    category VARCHAR(100) NOT NULL,
    priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
    status ENUM('open', 'in_progress', 'waiting_user', 'resolved', 'closed') DEFAULT 'open',
    subject VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    assigned_to INT NULL,
    resolution TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_category (category),
    INDEX idx_status (status),
    INDEX idx_priority (priority),
    INDEX idx_assigned_to (assigned_to)
);

-- Dispute cases
CREATE TABLE disputes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    contract_id INT NOT NULL,
    complainant_id INT NOT NULL,
    respondent_id INT NOT NULL,
    type ENUM('payment', 'work_quality', 'communication', 'contract_terms', 'other') NOT NULL,
    status ENUM('open', 'investigating', 'awaiting_response', 'resolved', 'closed') DEFAULT 'open',
    subject VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    resolution TEXT,
    resolver_id INT NULL,
    amount_disputed DECIMAL(10, 2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP NULL,
    
    FOREIGN KEY (contract_id) REFERENCES contracts(id) ON DELETE CASCADE,
    FOREIGN KEY (complainant_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (respondent_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (resolver_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_contract_id (contract_id),
    INDEX idx_complainant_id (complainant_id),
    INDEX idx_respondent_id (respondent_id),
    INDEX idx_status (status),
    INDEX idx_type (type)
);

-- =============================================
-- ANALYTICS AND TRACKING
-- =============================================

-- User activity logs
CREATE TABLE activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    action VARCHAR(100) NOT NULL,
    entity_type VARCHAR(50),
    entity_id INT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_user_id (user_id),
    INDEX idx_action (action),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_created_at (created_at)
);

-- Platform statistics (for admin dashboard)
CREATE TABLE platform_stats (
    id INT AUTO_INCREMENT PRIMARY KEY,
    metric_name VARCHAR(100) NOT NULL,
    metric_value DECIMAL(15, 2) NOT NULL,
    metric_date DATE NOT NULL,
    metadata JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    UNIQUE KEY unique_metric_date (metric_name, metric_date),
    INDEX idx_metric_name (metric_name),
    INDEX idx_metric_date (metric_date)
);

-- =============================================
-- FILE STORAGE
-- =============================================

-- File uploads
CREATE TABLE file_uploads (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    original_name VARCHAR(255) NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(500) NOT NULL,
    file_size INT NOT NULL,
    mime_type VARCHAR(100) NOT NULL,
    file_type ENUM('profile_picture', 'resume', 'portfolio', 'document', 'message_attachment', 'other') NOT NULL,
    entity_type VARCHAR(50), -- what this file is attached to
    entity_id INT, -- ID of the entity
    is_public BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_file_type (file_type),
    INDEX idx_entity (entity_type, entity_id),
    INDEX idx_created_at (created_at)
);

-- =============================================
-- SYSTEM CONFIGURATION
-- =============================================

-- System settings
CREATE TABLE system_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    data_type ENUM('string', 'integer', 'decimal', 'boolean', 'json') DEFAULT 'string',
    description TEXT,
    is_public BOOLEAN DEFAULT FALSE, -- can be accessed by frontend
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    
    INDEX idx_setting_key (setting_key),
    INDEX idx_is_public (is_public)
);

-- =============================================
-- INITIAL DATA INSERTS
-- =============================================

-- Insert default job categories
INSERT INTO job_categories (name, slug, description, icon) VALUES
('Cleaning & Housekeeping', 'cleaning-housekeeping', 'Residential and commercial cleaning services', 'fas fa-home'),
('Delivery & Transportation', 'delivery-transportation', 'Package delivery and transportation services', 'fas fa-truck'),
('Digital Services', 'digital-services', 'Online and digital work', 'fas fa-laptop'),
('Events & Entertainment', 'events-entertainment', 'Event planning and entertainment services', 'fas fa-calendar'),
('Gardening & Landscaping', 'gardening-landscaping', 'Garden maintenance and landscaping', 'fas fa-leaf'),
('Handyman & Repairs', 'handyman-repairs', 'Home and office repairs', 'fas fa-tools'),
('Caregiving & Personal Care', 'caregiving-personal-care', 'Personal care and assistance services', 'fas fa-heart'),
('Education & Tutoring', 'education-tutoring', 'Teaching and tutoring services', 'fas fa-graduation-cap');

-- Insert common skills
INSERT INTO skills (name, slug, category_id) VALUES
('House Cleaning', 'house-cleaning', 1),
('Office Cleaning', 'office-cleaning', 1),
('Deep Cleaning', 'deep-cleaning', 1),
('Food Delivery', 'food-delivery', 2),
('Package Delivery', 'package-delivery', 2),
('Moving Services', 'moving-services', 2),
('Web Development', 'web-development', 3),
('Graphic Design', 'graphic-design', 3),
('Data Entry', 'data-entry', 3),
('Photography', 'photography', 4),
('Videography', 'videography', 4),
('Event Setup', 'event-setup', 4),
('Lawn Mowing', 'lawn-mowing', 5),
('Garden Design', 'garden-design', 5),
('Tree Trimming', 'tree-trimming', 5),
('Plumbing', 'plumbing', 6),
('Electrical Work', 'electrical-work', 6),
('Painting', 'painting', 6),
('Elder Care', 'elder-care', 7),
('Child Care', 'child-care', 7),
('Pet Care', 'pet-care', 7),
('Math Tutoring', 'math-tutoring', 8),
('Language Teaching', 'language-teaching', 8),
('Music Lessons', 'music-lessons', 8);

-- Insert system settings
INSERT INTO system_settings (setting_key, setting_value, data_type, description, is_public) VALUES
('platform_name', 'CasualWork', 'string', 'Platform name', true),
('platform_commission', '5.0', 'decimal', 'Platform commission percentage', false),
('min_payout_amount', '10.00', 'decimal', 'Minimum payout amount', false),
('max_file_upload_size', '10485760', 'integer', 'Maximum file upload size in bytes (10MB)', false),
('allowed_file_types', '["jpg","jpeg","png","gif","pdf","doc","docx"]', 'json', 'Allowed file upload types', false),
('email_verification_required', 'true', 'boolean', 'Email verification required for new users', false),
('phone_verification_required', 'false', 'boolean', 'Phone verification required', false),
('background_check_required', 'false', 'boolean', 'Background check required for workers', false),
('auto_approve_jobs', 'false', 'boolean', 'Auto approve job postings', false),
('escrow_enabled', 'true', 'boolean', 'Enable escrow payments', false),
('maintenance_mode', 'false', 'boolean', 'Platform maintenance mode', true);

-- =============================================
-- END OF SCHEMA
-- =============================================

